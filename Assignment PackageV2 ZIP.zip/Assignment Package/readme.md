## HTML / CSS / JS PROJECT

## HARRISON AUSTIN-THOMAS

## GITHUB REPO ADDRESS

My repo is located at:

https://github.com/Attackez14/AssignmentPackage

## CONFIRMATION OF FILES

I confirm I have only included files needed to run the application

