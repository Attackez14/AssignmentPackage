document.querySelector("nav ul").addEventListener("click", function() {
    alert("You clicked a menu item!");
});